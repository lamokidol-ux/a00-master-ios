# A00 MASTER – Gói đóng gói iOS (.ipa) cho ESign

Bộ mã nguồn này bọc ứng dụng web **A00 MASTER – AI TUTOR SYSTEM** vào khung **Capacitor iOS** kèm sẵn **GitHub Actions** để tự động biên dịch file `A00-Master-unsigned.ipa` trên máy ảo macOS miễn phí (không cần máy Mac).

## Cấu trúc thư mục
- `www/index.html`: Ứng dụng web A00 MASTER hoàn chỉnh.
- `assets/icon-1024.png`: Biểu tượng khiên A00 MASTER độ phân giải 1024×1024 cho màn hình chính iPhone.
- `capacitor.config.json` & `package.json`: Cấu hình đóng gói app iOS (`com.a00master.aitutor`).
- `.github/workflows/build-ios-ipa.yml`: Quy trình tự động build file `.ipa` chưa ký (đã cấu hình sẵn quyền Camera & Thư viện ảnh cho AI Tutor).

## Các bước tạo file `.ipa` và cài qua ESign (không cần máy Mac)

### Bước 1: Đẩy mã nguồn lên GitHub
1. Tạo một repository mới trên GitHub (ví dụ: `a00-master-ios`, có thể để **Public** để dùng GitHub Actions macOS miễn phí).
2. Giải nén tệp `a00-master-ios-esign.zip` và tải toàn bộ thư mục/tệp bên trong (bao gồm cả thư mục ẩn `.github/workflows/build-ios-ipa.yml`) lên nhánh `main` của repository.

### Bước 2: Chạy build tự động để lấy file `.ipa`
1. Mở tab **Actions** trên repository GitHub của bạn.
2. Chọn workflow **Build iOS IPA (ESign)** ở cột bên trái → bấm **Run workflow** (hoặc chờ chạy tự động ngay sau khi push).
3. Chờ khoảng 3–5 phút để máy ảo macOS biên dịch xong (hiện dấu tích xanh).
4. Bấm vào lần chạy vừa xong, kéo xuống mục **Artifacts** và tải tệp **`A00-Master-unsigned-ipa`** (giải nén sẽ được file `A00-Master-unsigned.ipa`).

### Bước 3: Ký (Sign) và cài đặt bằng ESign trên iPhone
1. Chuyển file `A00-Master-unsigned.ipa` vào ứng dụng **Tệp (Files)** trên iPhone → chọn chia sẻ sang **ESign** (hoặc nhập trực tiếp trong ESign).
2. Trong ESign, vào mục **Ứng dụng (Apps)** → chọn `A00-Master-unsigned.ipa` → bấm **Ký (Signature)**.
3. Chọn chứng chỉ (Certificate) đang hoạt động của bạn (có thể đổi Bundle ID nếu muốn) → bấm **Ký** → bấm **Cài đặt (Install)**.

## Lưu ý bảo toàn dữ liệu khi dùng ESign
- Dữ liệu học tập hiện lưu cục bộ trong ứng dụng trên iPhone. Nếu chứng chỉ ESign bị thu hồi (revoke) phải cài lại, dữ liệu cục bộ có thể bị mất.
- Hãy định kỳ vào **Profile & Settings → Xuất file JSON** để lưu một bản dự phòng vào iCloud Drive / Tệp trên iPhone, sau khi cài lại chỉ cần bấm **Nhập file JSON** để khôi phục nguyên trạng.
